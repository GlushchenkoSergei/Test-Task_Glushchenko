import Foundation

// Основной метод сравнения версий
private func compereVersions(_ lhs: String, _ rhs: String) {
    
    guard let lhs = lhs.checkCharacters()?.correctVersion() else { return print("incorrect version") }
    guard let rhs = rhs.checkCharacters()?.correctVersion() else { return print("incorrect version") }
    
    let versionCompere = lhs.compare(rhs, options: .numeric)
    
    switch versionCompere {
    case .orderedAscending:
        print("\(rhs) > \(lhs)")
    case .orderedSame:
        print("\(rhs) = \(lhs)")
    case .orderedDescending:
        print("\(lhs) > \(rhs)")
    }
    
}

// Метод проверки допустимых символов
extension String {
    func checkCharacters() -> String? {
        var newString = ""
        
        for item in self {
            if let item = Int("\(item)") {
                newString.append("\(item)")
            } else if item == "." {
                newString.append("\(item)")
            } else {
                return nil
            }
        }
        
        return newString
    }
}

// Корректировка введенной версии (Пример: 0...1 -> 0.0.0.1)
extension String {
    func correctVersion() -> String {
        var newString = ""
        var oldCharacter = "."
        
        for item in self {
            if item == "." && oldCharacter == "."{
                newString.append("0.")
            } else {
                newString.append(item)
                oldCharacter = "\(item)"
            }
        }
        
        if newString.last == "." { newString.append("0") }
        
        if newString.count == 1 { return newString }
        let characterBeforeLast = findCharacter(of: newString, index: newString.count - 2)
        
        while newString.last == "0" && characterBeforeLast == "." && newString.count > 1 {
            newString.removeLast()
            newString.removeLast()
        }
        
        return newString
    }
    
    private func findCharacter(of string: String, index: Int) -> Character {
        let findIndex = string.index(string.startIndex, offsetBy: index)
        return string[findIndex]
    }
    
}

// MARK: - Решение задачи
let oneVersion = "0..4.1"
let towVersion = "01.234.56.10"

compereVersions(oneVersion, towVersion)

// MARK: - Решение задачи с некорректной версией
let versionWithError = "0..s.0"
let version = "01.234.56.10"

compereVersions(versionWithError, version)

